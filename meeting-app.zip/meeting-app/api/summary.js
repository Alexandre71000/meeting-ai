export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { client, title, participants, type, date, transcript } = req.body;

  if (!transcript || transcript.trim().length < 10) {
    return res.status(400).json({ error: 'Transcription trop courte' });
  }

  const prompt = `Tu es un assistant spécialisé pour les technico-commerciaux français.
À partir de la retranscription suivante, génère un compte rendu de réunion professionnel et structuré.

Contexte :
- Client : ${client || 'Non renseigné'}
- Objet : ${title || 'Réunion'}
- Type : ${type || 'Réunion'}
- Date : ${date}
- Participants : ${participants || 'Non renseignés'}

Retranscription :
${transcript}

Génère un compte rendu clair avec uniquement les sections pertinentes parmi :
1. Résumé (2-3 phrases)
2. Points clés abordés
3. Décisions prises
4. Actions à suivre (avec responsable si mentionné)
5. Prochaines étapes

Sois concis et professionnel. Texte brut sans markdown.`;

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${process.env.GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { maxOutputTokens: 1024, temperature: 0.3 }
        })
      }
    );

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error?.message || 'Erreur API Gemini');
    }

    const summary = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    return res.status(200).json({ summary });

  } catch (error) {
    console.error('API error:', error);
    return res.status(500).json({ error: 'Erreur lors de la génération du compte rendu' });
  }
}
